/* Capture Viewer. Native display adaptation uses GPL-3.0-or-later VideoOut examples. */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <errno.h>
#include "uvc.h"
#include "mjpeg_decode.h"
#include "videoout.h"
#include "font.h"
#define W 1920
#define H 1080
#define STRIDE 10485760
extern size_t sceKernelGetDirectMemorySize(void);
extern int sceKernelAllocateDirectMemory(int64_t,int64_t,size_t,size_t,int,int64_t*);
extern int sceKernelMapDirectMemory(void**,size_t,int,int,int64_t,size_t);
extern int sceKernelMunmap(void*,size_t);
extern int sceKernelReleaseDirectMemory(int64_t,size_t);
extern int sceSystemServiceHideSplashScreen(void);
extern int sceUserServiceInitialize(const void*);
extern int sceUserServiceGetForegroundUser(int*);
extern int sceUserServiceGetInitialUser(int*);
extern int scePadInit(void);
extern int scePadOpen(int,int,int,const void*);
extern int scePadReadState(int,void*);
extern int scePadClose(int);
static FILE*logfile;static int video=-1,back;static unsigned char*memory;static int64_t physical=-1;static uint64_t serial,render_ms;
static uint64_t millis(){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000+t.tv_nsec/1000000;}
static size_t tile(unsigned x,unsigned y){return ((size_t)((y>>7)*15+(x>>7))<<16)+(((y<<4)&0x70)^((y<<5)&0xf00)^((y<<9)&0x1000)^((y<<8)&0x4000)^((x<<2)&0xc)^((x<<5)&0x380)^((x<<4)&0x400)^((x<<6)&0x800)^((x<<9)&0xa000));}
static void pixel(int x,int y,uint32_t c){if(x>=0&&y>=0&&x<W&&y<H)*(uint32_t*)(memory+back*STRIDE+tile(x,y))=c;}
static void text(int x,int y,const char*s){for(;*s;s++,x+=20){unsigned ch=(unsigned char)*s;if(ch>=128)ch='?';for(int j=0;j<20;j++)for(int i=0;i<10;i++)if(font[ch][j]&(1<<i))for(int dy=0;dy<2;dy++)for(int dx=0;dx<2;dx++)pixel(x+i*2+dx,y+j*2+dy,0xffffffff);}}
static int present(){for(int i=0;i<1000&&sceVideoOutIsFlipPending(video)>0;i++)usleep(1000);if(sceVideoOutIsFlipPending(video)>0)return -1;unsigned char*b=memory+back*STRIDE;for(size_t i=0;i<STRIDE;i+=64)__asm__ volatile("clflush (%0)"::"r"(b+i):"memory");__asm__ volatile("sfence":::"memory");int r=sceVideoOutSubmitFlip(video,back,1,++serial);back^=1;return r;}
static void message(const char*s){memset(memory+back*STRIDE,0,STRIDE);text(80,80,"CAPTURE VIEWER");text(80,160,s);text(80,240,"Circle: close viewer");present();}
static uint32_t offsets[W*H];
static void render(Capture*c){static int initialized;if(!initialized){for(int y=0;y<H;y++)for(int x=0;x<W;x++)offsets[y*W+x]=tile(x,y);initialized=1;}unsigned char *dst=memory+back*STRIDE;const uint32_t *src=(const uint32_t*)c->frame;for(int i=0;i<W*H;i++)*(uint32_t*)(dst+offsets[i])=src[i];present();}
static void save_frame(Capture*c){FILE*f=fopen("/data/codex-viewer-frame.tmp","wb");if(!f)return;fprintf(f,"P6\n%d %d\n255\n",CAP_WIDTH,CAP_HEIGHT);unsigned char row[CAP_WIDTH*3];for(int y=0;y<CAP_HEIGHT;y++){for(int x=0;x<CAP_WIDTH;x++){unsigned v=capture_pixel(c->frame,x,y);row[x*3]=v>>16;row[x*3+1]=v>>8;row[x*3+2]=v;}fwrite(row,1,sizeof(row),f);}int failed=ferror(f);int closed=fclose(f);if(!failed&&!closed)rename("/data/codex-viewer-frame.tmp","/data/codex-viewer-frame.ppm");}
static int local_connect(int port){int s=socket(AF_INET,SOCK_STREAM,0);struct sockaddr_in a={0};a.sin_family=AF_INET;a.sin_port=htons(port);inet_pton(AF_INET,"127.0.0.1",&a.sin_addr);if(s<0||connect(s,(void*)&a,sizeof(a))){if(s>=0)close(s);return -1;}return s;}
static int service_connect(){int s=local_connect(9983);if(s>=0)return s;int h=local_connect(8084);if(h>=0){const char*q="GET /loadpayload:codex-capture-service.elf HTTP/1.0\r\nHost: localhost\r\n\r\n";send(h,q,strlen(q),0);struct timeval t={3,0};setsockopt(h,SOL_SOCKET,SO_RCVTIMEO,&t,sizeof(t));char b[512];while(recv(h,b,sizeof(b),0)>0){}close(h);}for(int i=0;i<30;i++){s=local_connect(9983);if(s>=0)return s;usleep(100000);}return -1;}
static int service_poll(int fd,Capture*c){static uint32_t header[5];static size_t got;while(1){size_t total=sizeof(header)+(got>=sizeof(header)?header[3]:0);if(got==total&&got>=sizeof(header)){got=0;int dr=mjpeg_decode_bgra(c->jpeg,header[3],c->frame,CAP_BYTES);if(dr){c->dropped++;fprintf(logfile,"JPEG rejected code=%d size=%u\n",dr,header[3]);return 2;}c->frames++;c->bytes+=header[3];return 1;}void*p=got<sizeof(header)?(void*)((unsigned char*)header+got):(void*)(c->jpeg+got-sizeof(header));size_t n=got<sizeof(header)?sizeof(header)-got:total-got;ssize_t z=recv(fd,p,n,MSG_DONTWAIT);if(z<0)return errno==EAGAIN?0:-1;if(!z)return -1;got+=z;if(got==sizeof(header)&&(header[0]!=0x33504143||header[1]!=CAP_WIDTH||header[2]!=CAP_HEIGHT||header[3]>sizeof(c->jpeg)||header[3]<4))return -1;}}
int main(){logfile=fopen("/data/codex-capture-viewer.log","w");if(!logfile)return 1;setvbuf(logfile,0,_IOLBF,0);fprintf(logfile,"Capture Viewer 1080p BGRA optimized v1 start bounded=%d\n",
#ifdef VIEWER_TEST
1
#else
0
#endif
);int exitcode=1,pad=-1,service=-1;static Capture storage;Capture*c=&storage;c->data=c->control=-1;video=sceVideoOutOpen(0xff,0,0,0);fprintf(logfile,"VideoOut open=%#x\n",video);if(video<0)goto cleanup;int r=sceKernelAllocateDirectMemory(0,sceKernelGetDirectMemorySize(),2*STRIDE,0x200000,3,&physical);if(!r)r=sceKernelMapDirectMemory((void**)&memory,2*STRIDE,0x33,0,physical,0x200000);fprintf(logfile,"direct memory=%#x\n",r);if(r)goto cleanup;unsigned char attr[80]={0};struct ps5_video_out_buffer buffers[2]={{memory,0,{0}},{memory+STRIDE,0,{0}}};sceVideoOutSetBufferAttribute2(attr,PS5_VIDEO_OUT_PIXEL_FORMAT_B8G8R8A8_SDR,0,W,H,0,0,0);r=sceVideoOutRegisterBuffers2(video,0,0,buffers,2,attr,0,0);fprintf(logfile,"register=%#x\n",r);if(r)goto cleanup;sceSystemServiceHideSplashScreen();sceUserServiceInitialize(0);scePadInit();int user=-1;if(!sceUserServiceGetForegroundUser(&user)||!sceUserServiceGetInitialUser(&user))pad=scePadOpen(user,0,0,0);message("Opening USB capture card...");char err[256];r=capture_open(c,err,sizeof(err));fprintf(logfile,"capture=%d %s payload=%u\n",r,err,c->payload);if(r){message("Starting capture helper...");service=service_connect();fprintf(logfile,"helper connection=%d\n",service);if(service>=0)r=0;else message("Capture helper unavailable. Reopen viewer.");}uint64_t start=millis(),last=start,lastframe=start,lastsample=0,lastrequest=0;int startup_saved=0;unsigned prev=0;exitcode=0;
while(1){uint64_t now=millis();
#ifdef VIEWER_TEST
if(now-start>20000)break;
#endif
struct{uint32_t buttons;unsigned char rest[508];}state={0};if(pad>=0&&!scePadReadState(pad,&state)){if((state.buttons&~prev)&0x2000)break;prev=state.buttons;}
if(!r){int n=service>=0?service_poll(service,c):capture_poll(c);if(n<0){fprintf(logfile,"capture read error\n");message("Capture card disconnected. Close and reopen.");r=-1;capture_close(c);}else if(n==1){lastframe=now;uint64_t rt=millis();render(c);render_ms+=millis()-rt;if(now-lastsample>=5000){unsigned low=255,high=0;uint64_t sum=0;uint32_t hash=2166136261u;for(size_t i=0;i<CAP_BYTES;i++){hash=(hash^c->frame[i])*16777619u;if(!(i&1)){unsigned v=c->frame[i];if(v<low)low=v;if(v>high)high=v;sum+=v;}}fprintf(logfile,"pixels frame=%llu y_min=%u y_max=%u y_mean=%u hash=%08x\n",(unsigned long long)c->frames,low,high,(unsigned)(sum/(CAP_BYTES/2)),hash);lastsample=now;}if(!startup_saved&&c->frames>=20){save_frame(c);startup_saved=1;fprintf(logfile,"startup snapshot frame=%llu\n",(unsigned long long)c->frames);}if(now-lastrequest>=1000){lastrequest=now;FILE *request=fopen("/data/codex-viewer-snapshot.request","rb");if(request){fclose(request);save_frame(c);int ur=unlink("/data/codex-viewer-snapshot.request");fprintf(logfile,"snapshot frame=%llu unlink=%d errno=%d\n",(unsigned long long)c->frames,ur,errno);}}}else if(!n) usleep(200);}else usleep(20000);
if(now-last>=1000){uint64_t status[16]={0};int sr=sceVideoOutGetFlipStatus(video,status);fprintf(logfile,"elapsed=%llu frames=%llu bytes=%llu dropped=%llu flip=%llu shown=%llu status=%#x age_ms=%llu\n",(unsigned long long)(now-start),(unsigned long long)c->frames,(unsigned long long)c->bytes,(unsigned long long)c->dropped,(unsigned long long)serial,(unsigned long long)status[3],sr,(unsigned long long)(now-lastframe));fprintf(logfile,"render_ms=%llu\n",(unsigned long long)render_ms);last=now;}}
cleanup:if(service>=0)close(service);capture_close(c);if(pad>=0)scePadClose(pad);if(video>=0){sceVideoOutSubmitFlip(video,-1,1,0);for(int i=0;i<2000&&sceVideoOutIsFlipPending(video)>0;i++)usleep(1000);sceVideoOutUnregisterBuffers(video,0);sceVideoOutClose(video);}if(memory)sceKernelMunmap(memory,2*STRIDE);if(physical>=0)sceKernelReleaseDirectMemory(physical,2*STRIDE);
fprintf(logfile,"exit=%d\n",exitcode);fclose(logfile);return exitcode;}
