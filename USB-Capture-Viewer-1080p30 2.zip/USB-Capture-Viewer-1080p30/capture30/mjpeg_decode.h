#ifndef MJPEG_DECODE_H
#define MJPEG_DECODE_H
#include <stddef.h>
/* Returns zero only for a complete 1920x1080 JPEG decoded into BGRA. */
int mjpeg_decode_bgra(const unsigned char*,size_t,unsigned char*,size_t);
#endif
