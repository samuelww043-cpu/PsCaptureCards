1080p capture optimization

Installed title: PPSA99993 on receiver 192.168.43.227. Helper binds 127.0.0.1:9983.
Backups: old-eboot.bin and old-service.elf are the native1080p ~10fps build read from the console before modification.

Changes:
- Helper forwards complete validated UVC MJPEG payloads, without decoding or sending expanded pixels.
- Protocol magic 0x33504143, five little-endian uint32 fields: magic,width,height,JPEG length,source sequence; followed by JPEG bytes.
- Viewer validates bounded dimensions and length, decodes to BGRA, then copies into the existing tiled VideoOut buffers using precalculated offsets.
- capture_poll returns 2 for consumed partial USB payload,0 for idle,1 for complete frame,-1 for failure. Only idle reads sleep.
- Removed periodic snapshot writes; one startup snapshot remains. An explicit /data/codex-viewer-snapshot.request still triggers a snapshot; rows are written in bulk.
- Display buffer allocation and cache flushing remain as before. No source console settings changed.
- Capture storage is static in the title; the prior expanded allocation exceeded title libc heap.

Build: python3 capture30/build.py from codex-a workspace. Payload helper:
host-access/build-app/deps/ps5-payload-sdk/bin/prospero-clang -O3 capture30/service.c capture30/uvc.c capture30/mjpeg_decode.c -o capture30/service.elf

The function mjpeg_decode_bgra outputs BGRA (CAP_BYTES=1920*1080*4). Both viewer and helper must be built together; older protocol versions are rejected. Unused libjpeg-turbo checkout is experimental preparation only and is not linked or installed.

Deployment update.py writes and reads back both binaries, resuming partial reads. restart.py uses a separately compiled close payload with freshly verified viewer/helper PIDs; never reuse stale PIDs. deploy.py was used only for initial backup/deployment.
