#define STBI_ONLY_JPEG
#define STBI_NO_STDIO
#define STBI_NO_HDR
#define STBI_NO_LINEAR
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "mjpeg_decode.h"
int mjpeg_decode_bgra(const unsigned char *src,size_t n,unsigned char *out,size_t cap){
 int w=0,h=0,k=0;
 if(!src||!out||n<4||n>8294400||cap<8294400||src[0]!=255||src[1]!=216||src[n-2]!=255||src[n-1]!=217)return -1;
 if(!stbi_info_from_memory(src,(int)n,&w,&h,&k)||w!=1920||h!=1080)return -2;
 unsigned char *rgb=stbi_load_from_memory(src,(int)n,&w,&h,&k,4);
 if(!rgb)return -3;
 for(size_t i=0;i<1920u*1080u*4;i+=4){out[i]=rgb[i+2];out[i+1]=rgb[i+1];out[i+2]=rgb[i];out[i+3]=255;}
 stbi_image_free(rgb);return 0;
}
