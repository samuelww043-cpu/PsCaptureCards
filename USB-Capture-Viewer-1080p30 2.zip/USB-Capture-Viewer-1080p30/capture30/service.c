#include "uvc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <errno.h>
static int sendall(int fd,const void*p,size_t n){const unsigned char*b=p;while(n){ssize_t z=send(fd,b,n,0);if(z<=0)return -1;b+=z;n-=z;}return 0;}
int main(){int s=socket(AF_INET,SOCK_STREAM,0);if(s<0)return 1;int one=1;setsockopt(s,SOL_SOCKET,SO_REUSEADDR,&one,sizeof(one));struct sockaddr_in a={0};a.sin_family=AF_INET;a.sin_port=htons(9983);inet_pton(AF_INET,"127.0.0.1",&a.sin_addr);if(bind(s,(void*)&a,sizeof(a))||listen(s,1)){close(s);return 0;}FILE*f=fopen("/data/codex-capture-service.log","w");if(!f){close(s);return 1;}setvbuf(f,0,_IOLBF,0);fprintf(f,"service listening 127.0.0.1:9983 pid=%d\n",getpid());signal(SIGPIPE,SIG_IGN);struct timeval timeout={120,0};setsockopt(s,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));Capture*c=calloc(1,sizeof(*c));if(!c){fclose(f);close(s);return 1;}while(1){int fd=accept(s,0,0);if(fd<0)break;fprintf(f,"client connected\n");timeout.tv_sec=2;setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof(timeout));char error[256];if(capture_open(c,error,sizeof(error))){fprintf(f,"capture failed %s\n",error);close(fd);continue;}c->raw=1;fprintf(f,"capture started %s\n",error);time_t last=time(0);uint64_t send_us=0;while(1){int r=capture_poll(c);if(r<0)break;if(r==1){uint32_t header[5]={0x33504143,CAP_WIDTH,CAP_HEIGHT,(uint32_t)c->jpeg_size,(uint32_t)c->frames};struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);uint64_t t=(uint64_t)ts.tv_sec*1000000+ts.tv_nsec/1000;if(sendall(fd,header,sizeof(header))||sendall(fd,c->jpeg,c->jpeg_size))break;clock_gettime(CLOCK_MONOTONIC,&ts);send_us+=(uint64_t)ts.tv_sec*1000000+ts.tv_nsec/1000-t;}else if(!r) usleep(200);if(time(0)-last>=5){fprintf(f,"frames=%llu bytes=%llu dropped=%llu\n",(unsigned long long)c->frames,(unsigned long long)c->bytes,(unsigned long long)c->dropped);fprintf(f,"timing frames=%llu read_us=%llu decode_us=%llu send_us=%llu\n",(unsigned long long)c->frames,(unsigned long long)c->read_us,(unsigned long long)c->decode_us,(unsigned long long)send_us);last=time(0);}}fprintf(f,"client ended frames=%llu dropped=%llu errno=%d\n",(unsigned long long)c->frames,(unsigned long long)c->dropped,errno);capture_close(c);close(fd);}fprintf(f,"service stopped (idle timeout)\n");free(c);close(s);fclose(f);return 0;}
