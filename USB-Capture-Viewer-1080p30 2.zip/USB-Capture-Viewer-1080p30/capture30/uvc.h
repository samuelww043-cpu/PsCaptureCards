#ifndef CAPTURE_UVC_H
#define CAPTURE_UVC_H
#include <stddef.h>
#include <stdint.h>
#define CAP_WIDTH 1920
#define CAP_HEIGHT 1080
#define CAP_BYTES (CAP_WIDTH*CAP_HEIGHT*4)
typedef struct {int control,data,fid,started,raw;unsigned payload;size_t used,jpeg_size;uint64_t bytes,frames,dropped,read_us,decode_us;unsigned char frame[CAP_BYTES]; unsigned char jpeg[CAP_WIDTH*CAP_HEIGHT*2];} Capture;
int capture_open(Capture*,char*,size_t);
int capture_poll(Capture*);
void capture_close(Capture*);
uint32_t capture_pixel(const unsigned char*,int,int);
#endif
