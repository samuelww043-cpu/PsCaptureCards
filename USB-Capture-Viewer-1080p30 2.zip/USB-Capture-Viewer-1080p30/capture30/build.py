from pathlib import Path
import subprocess,shutil,json,hashlib,sys
root=Path(__file__).resolve().parent
base=(root.parent/'host-access').resolve();app=base/'build-app';sdk=app/'deps/ps5-payload-sdk';native=base/'sources/PS5_Vulkan/tooling/native';out=root/'build';out.mkdir(exist_ok=True)
release=root/'release/PPSA99993';release.mkdir(parents=True,exist_ok=True)
def run(a):subprocess.run(list(map(str,a)),check=True)
cc=sdk/'bin/prospero-clang'
run([sdk/'bin/prospero-clang++','-c','-O3','-fPIE','-fno-exceptions','-fno-rtti',app/'native/app_crt.cpp','-o',out/'app_crt.o'])
run([cc,'-c','-O3',app/'native/fp.c','-o',out/'fp.o'])
for name in ['viewer','uvc','mjpeg_decode']:
 flags=['-DVIEWER_TEST'] if '--test' in sys.argv else []
 run([cc,'-O3','-Wall',*flags,'-I'+str(app),'-c',root/(name+'.c'),'-o',out/(name+'.o')])
libs=[sdk/'target/lib'/('lib'+n+'.so') for n in ['kernel','SceUserService','SceVideoOut','SceSystemService','ScePad','SceLibcInternal','c_stub_weak','SceNet']]
run([sdk/'bin/prospero-lld','-pie','-T',native/'ps5-pie.ld','--eh-frame-hdr','-e','_start','-o',out/'llvm-pie.elf',*[out/(x+'.o') for x in ['viewer','uvc','mjpeg_decode','app_crt','fp']],'--as-needed',*libs,sdk/'target/lib/libc.a'])
run([base/'native-tools/ps5-native-tool','link','--in',out/'llvm-pie.elf','--out',out/'eboot.elf','--stub-dir',sdk/'target/lib','--module-sdk','0x02000009','--companion-sdk','0x08050001','--file-name','eboot.elf'])
run([base/'native-tools/ps5-native-tool','self','--sign','--in',out/'eboot.elf','--out',release/'eboot.bin','--magic','0x1D3D154F'])
(release/'eboot.bin').chmod(0o755)
(release/'sce_module').mkdir(exist_ok=True);shutil.copy2(base/'native-tools/libc.prx',release/'sce_module/libc.prx')
(release/'sce_sys').mkdir(exist_ok=True)
p=json.loads((base/'release/PPSA99994/sce_sys/param.json').read_text());p.update(titleId='PPSA99993',conceptId='99993',contentId='UP9000-PPSA99993_00-CAPTUREVIEWER0001');p['localizedParameters']['en-US']['titleName']='USB Capture Viewer'
(release/'sce_sys/param.json').write_text(json.dumps(p,indent=2)+'\n')
shutil.copy2(root/'icon0.png',release/'sce_sys/icon0.png')
(release/'LICENSES').mkdir(exist_ok=True)
for name in ['FONT-LICENSE','TILE-LICENSE']:shutil.copy2(app/name,release/'LICENSES'/name)
manifest={str(p.relative_to(release)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(release.rglob('*')) if p.is_file() and p.name!='manifest.json'}
(release/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(release)
