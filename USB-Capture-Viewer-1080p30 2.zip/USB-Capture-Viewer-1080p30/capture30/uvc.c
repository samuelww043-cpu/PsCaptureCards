#include "uvc.h"
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/ioctl.h>
#include <dev/usb/usb_ioctl.h>
#include "mjpeg_decode.h"
#include <time.h>
static uint64_t micros(){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000+t.tv_nsec/1000;}
static int request(int fd,int type,int req,int sel,unsigned char*p){struct usb_ctl_request q={.ucr_data=p};q.ucr_request.bmRequestType=type;q.ucr_request.bRequest=req;USETW(q.ucr_request.wValue,sel<<8);USETW(q.ucr_request.wIndex,1);USETW(q.ucr_request.wLength,26);return ioctl(fd,USB_DO_REQUEST,&q);}
void capture_close(Capture*c){if(c->data>=0)close(c->data);if(c->control>=0)close(c->control);c->control=c->data=-1;}
int capture_open(Capture*c,char*error,size_t max){memset(c,0,sizeof(*c));c->control=c->data=-1;c->fid=-1;DIR*d=opendir("/dev");if(!d){snprintf(error,max,"Cannot list USB devices: %s",strerror(errno));return -1;}char node[128]={0};struct dirent*e;while((e=readdir(d))){if(strncmp(e->d_name,"ugen",4))continue;snprintf(node,sizeof(node),"/dev/%s",e->d_name);int fd=open(node,O_RDWR);if(fd<0)continue;struct usb_device_descriptor dd={0};if(!ioctl(fd,USB_GET_DEVICE_DESC,&dd)&&UGETW(dd.idVendor)==0x345f&&UGETW(dd.idProduct)==0x2131){c->control=fd;break;}close(fd);}closedir(d);if(c->control<0){snprintf(error,max,"Connect UltraSemi USB2 Video capture card");return -1;}
unsigned char p[26]={0};if(request(c->control,0xa1,0x81,1,p))goto fail;p[0]=1;p[1]=0;p[2]=1;p[3]=1;p[4]=0x15;p[5]=0x16;p[6]=0x05;p[7]=0;
if(request(c->control,0x21,1,1,p)||request(c->control,0xa1,0x81,1,p))goto fail;
c->payload=(unsigned)p[22]|((unsigned)p[23]<<8)|((unsigned)p[24]<<16)|((unsigned)p[25]<<24);if(c->payload<12||c->payload>65536){errno=EINVAL;goto fail;}if(request(c->control,0x21,1,2,p))goto fail;
unsigned bus,addr;if(sscanf(node,"/dev/ugen%u.%u",&bus,&addr)!=2){errno=EINVAL;goto fail;}snprintf(node,sizeof(node),"/dev/usb/%u.%u.3",bus,addr);c->data=open(node,O_RDONLY|O_NONBLOCK);if(c->data<0)goto fail;int x=1;if(ioctl(c->data,USB_SET_RX_SHORT_XFER,&x))goto fail;x=200;if(ioctl(c->data,USB_SET_RX_TIMEOUT,&x))goto fail;x=c->payload;if(ioctl(c->data,USB_SET_RX_BUFFER_SIZE,&x))goto fail;snprintf(error,max,"1920 x 1080 / 30 fps / MJPEG mode");return 0;
fail:snprintf(error,max,"USB video setup failed: %s",strerror(errno));capture_close(c);return -1;}
/* Every read is at most the negotiated UVC payload size, preserving short bulk boundaries. */
int capture_poll(Capture*c){unsigned char b[65536];uint64_t t=micros();ssize_t n=read(c->data,b,c->payload);c->read_us+=micros()-t;if(n<0)return errno==EAGAIN?0:-1;if(!n)return 0;c->bytes+=n;if(n<2||b[0]<2||b[0]>n||!(b[1]&0x80)){c->used=0;c->started=0;c->dropped++;return 2;}int fid=b[1]&1;if(fid!=c->fid){if(c->used)c->dropped++;c->used=0;c->started=1;c->fid=fid;}if(b[1]&0x40){c->used=0;c->started=0;c->dropped++;return 2;}size_t z=n-b[0];if(c->started&&z<=sizeof(c->jpeg)-c->used){memcpy(c->jpeg+c->used,b+b[0],z);c->used+=z;}else if(z){c->started=0;c->used=0;c->dropped++;}if(b[1]&2){int good=c->started&&c->used>0;size_t jpeg_size=c->used;c->started=0;c->used=0;if(good){if(jpeg_size<4||c->jpeg[0]!=255||c->jpeg[1]!=216||c->jpeg[jpeg_size-2]!=255||c->jpeg[jpeg_size-1]!=217){c->dropped++;return 2;}c->jpeg_size=jpeg_size;if(!c->raw){t=micros();int dr=mjpeg_decode_bgra(c->jpeg,jpeg_size,c->frame,CAP_BYTES);c->decode_us+=micros()-t;if(dr){c->dropped++;return 2;}}c->frames++;return 1;}if(z)c->dropped++;}return 2;}
uint32_t capture_pixel(const unsigned char*b,int x,int y){uint32_t v;memcpy(&v,b+(y*CAP_WIDTH+x)*4,4);return v;}
