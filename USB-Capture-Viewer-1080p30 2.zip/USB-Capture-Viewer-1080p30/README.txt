USB Capture Viewer - native 1920x1080 near 30fps

Compiled PS5 app: capture30/release/PPSA99993/
Required capture helper: capture30/service.elf
These are PS5 homebrew binaries, not macOS applications. Both use the matching optimized JPEG transport protocol.

Source: capture30/*.c and *.h. Build support/dependencies are under host-access/.
Build on Linux with Python 3 and clang/lld available: python3 capture30/build.py
Build helper from this folder:
host-access/build-app/deps/ps5-payload-sdk/bin/prospero-clang -O3 capture30/service.c capture30/uvc.c capture30/mjpeg_decode.c -o capture30/service.elf
The included native tools are Linux executables. SDK scripts may require the toolchain described in the SDK documentation.

Verified installed build: 5883 displayed frames in 197.056 seconds (29.854 fps), animated PS5 home menu. Gameplay untested. See capture30/checkpoint.json and evidence logs/images. No console configuration is changed by extracting this archive.
